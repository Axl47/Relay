export declare const enum APIOrderBy {
    AUTHOR = "author",
    DATE = "date",
    ID = "id",
    MODIFIED = "modified",
    RELEVANCE = "relevance",
    TITLE = "title"
}
export declare const enum APIOrder {
    ASCENDING = "asc",
    DESCENDING = "desc"
}
