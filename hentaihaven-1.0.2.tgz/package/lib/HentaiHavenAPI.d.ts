import { RequestInit } from 'node-fetch';
import { APITag } from './api-types/APITag';
import { HentaiHavenVideo } from './HentaiHavenVideo';
import { APISeries } from './api-types/APISeries';
import { APIImage } from './api-types/APIImage';
import { APISearchRequest } from './api-types/APISearchRequest';
import { HentaiHavenSearch } from './HentaiHavenSearch';
export declare type HentaiHavenOptions = {
    fetch_options?: RequestInit;
    timeout?: number;
};
export declare type HentaiHavenTag = {
    id: number;
    count: number;
    description: string;
    link: string;
    name: string;
    slug: string;
};
export declare type HentaiHavenSeries = {
    id: string;
    count: number;
    description: string;
    link: string;
    name: string;
    slug: string;
};
export declare class HentaiHavenAPI {
    private options?;
    private static tags;
    static get_tags(include_unused?: boolean): Promise<APITag[]>;
    constructor(options?: HentaiHavenOptions);
    private get_fetch_options;
    get_video(id: string | number): Promise<HentaiHavenVideo>;
    get_video_series(video: string | number | HentaiHavenVideo): Promise<Omit<APISeries, '_links'>>;
    get_video_image(video: HentaiHavenVideo): Promise<Omit<APIImage, '_links'>>;
    search(query: string): Promise<HentaiHavenSearch>;
    search(request: APISearchRequest): Promise<HentaiHavenSearch>;
    private api_search;
    private api_fetch;
}
