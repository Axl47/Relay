import { APIVideo } from './api-types/APIVideo';
import { APITag } from './api-types/APITag';
import { HentaiHavenTag } from './HentaiHavenAPI';
export declare class HentaiHavenVideo {
    private data;
    tags: HentaiHavenTag[];
    constructor(data: APIVideo, tags: APITag[]);
    get id(): number;
    get date_aired(): string;
    get date_modified(): string;
    get slug(): string;
    get link(): string;
    get title(): string;
    get raw(): APIVideo;
}
