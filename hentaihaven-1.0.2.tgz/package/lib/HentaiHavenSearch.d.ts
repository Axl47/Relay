import { WPPaginatedResponse } from './api-types/WPPaginatedResponse';
import { APIVideo } from './api-types/APIVideo';
import { APITag } from './api-types/APITag';
import { HentaiHavenVideo } from './HentaiHavenVideo';
export declare class HentaiHavenSearch {
    private data;
    results: HentaiHavenVideo[];
    constructor(data: WPPaginatedResponse<APIVideo>, tags: APITag[]);
    get pages(): number;
    get total(): number;
    get raw(): WPPaginatedResponse<APIVideo>;
}
